package Mall;

import bank.BalanceException;

public class ShoppingCart {
	private Product[] items;
	private int count;
	private double total;
	public ShoppingCart() {
		items = new Product[5];
		count = 0;
		total = 0.0;
	}
	public void addToCart(Product p) throws AddCartException {
		if(count<items.length) {
			items[count] = p;
			count++;
			total+=p.getPrice();
			System.out.println(count+".Item Name: "+p.getName()+"\nItem Price: "+p.getPrice()+"\n");
		}
		else {
			throw new AddCartException("The Cart is Full!Cannot add more items.");
		}
		
	}
	public void checkout() {
		System.out.println("\nBill:");
		for(int i=0;i<count;i++) {
			System.out.println((i+1)+".Item Name:"+items[i].getName()+"\nItem Price: "+items[i].getPrice()+"\n");
		}
		System.out.println("Total Bill is: "+total);
	}
}
